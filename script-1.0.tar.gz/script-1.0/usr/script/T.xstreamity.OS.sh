#!/bin/sh
#

wget -O /var/volatile/tmp/xstreamity_3.16_all.deb "https://github.com/tarekzoka/-xstreamity/raw/main/enigma2-plugin-extensions-xstreamity_3.16_all.deb"
wait
opkg install --force-overwrite /tmp/*.deb
wait
sleep 2;
